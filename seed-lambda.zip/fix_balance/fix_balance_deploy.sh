#!/bin/bash
# fix_balance_deploy.sh
# Deploys rebalanced driver/rider logic to all Lambdas
# Usage: bash fix_balance_deploy.sh YOUR_ACCOUNT_ID
# Run from fix_balance/ folder

ACCOUNT_ID=$1
REGION="ap-south-1"

if [ -z "$ACCOUNT_ID" ]; then
  echo "❌ Usage: bash fix_balance_deploy.sh YOUR_ACCOUNT_ID"
  exit 1
fi

echo "🔧 Deploying driver/rider balance fix..."
echo ""
echo "Changes:"
echo "  Drivers:        70 → 35   (fewer drivers in city)"
echo "  Riders:         40 → 80   (more riders requesting)"
echo "  City radius:    8km → 5km (tighter = more overlap in 3km search)"
echo "  Rider cluster:  60% spawn within 2.5km of center"
echo "  Move speed:     0.4 → 0.25km/tick (drivers stay in range longer)"
echo "  Driver toggle:  8% → 12%  (more go offline = fewer available)"
echo "  Add/tick:       5-8 → 8-12 riders"
echo "  Min riders:     25 → 40"
echo ""

# ── Package and deploy each Lambda ───────────────────────────────────────────
deploy() {
  FUNC=$1; DIR=$2
  echo -n "  📦 $FUNC ... "
  cp shared/utils.py "$DIR/utils.py"
  cd "$DIR"
  zip -r "../../${FUNC}.zip" . -x "*.pyc" "__pycache__/*" > /dev/null
  cd ..
  rm -f "$DIR/utils.py"
  aws lambda update-function-code \
    --function-name "$FUNC" \
    --zip-file "fileb://${FUNC}.zip" \
    --region "$REGION" \
    --query "FunctionName" --output text > /dev/null
  rm -f "${FUNC}.zip"
  echo "✅"
}

deploy "seed-lambda"          "seed_lambda"
deploy "move-drivers-lambda"  "move_drivers_lambda"
deploy "expire-riders-lambda" "expire_riders_lambda"

# Redeploy API lambdas with updated utils.py
echo ""
echo "  Updating utils.py in API Lambdas..."
for ENTRY in \
  "drivers-lambda:../phase3/api_lambdas/drivers" \
  "riders-lambda:../phase3/api_lambdas/riders" \
  "demand-lambda:../phase3/api_lambdas/demand" \
  "price-lambda:../phase3/api_lambdas/price" \
  "driver-tips-lambda:../phase3/api_lambdas/driver_tips"
do
  FUNC=$(echo "$ENTRY" | cut -d: -f1)
  DIR=$(echo "$ENTRY" | cut -d: -f2)
  if [ -d "$DIR" ]; then
    deploy "$FUNC" "$DIR"
  else
    echo "  ⚠  $DIR not found — copy utils.py manually"
  fi
done

echo ""

# ── Re-seed DynamoDB with new balanced values ─────────────────────────────────
echo "🌱 Re-seeding DynamoDB with balanced data..."
aws lambda invoke \
  --function-name seed-lambda \
  --region "$REGION" \
  /tmp/seed_result.json > /dev/null

cat /tmp/seed_result.json
echo ""

# ── Verify the balance ────────────────────────────────────────────────────────
echo "🔍 Verifying DynamoDB counts..."
D=$(aws dynamodb scan --table-name drivers --select COUNT --region "$REGION" --query "Count" --output text)
R=$(aws dynamodb scan --table-name riders  --select COUNT --region "$REGION" --query "Count" --output text)
echo "  drivers: $D"
echo "  riders:  $R"

if [ -n "$D" ] && [ -n "$R" ] && [ "$D" -gt 0 ] && [ "$R" -gt 0 ]; then
  RATIO=$(echo "scale=2; $R / $D" | bc 2>/dev/null || echo "~$(($R / $D)).x")
  echo "  ratio:   ${RATIO}x riders per driver"
  echo ""
  if [ "$R" -gt "$D" ]; then
    echo "  ✅ Riders now OUTNUMBER drivers — surge pricing will activate"
  else
    echo "  ⚠  Drivers still outnumber riders — try re-seeding again"
    echo "     aws lambda invoke --function-name seed-lambda --region $REGION /tmp/s.json && cat /tmp/s.json"
  fi
fi

echo ""
echo "════════════════════════════════════════════════════"
echo "  ✅ Balance fix deployed"
echo ""
echo "  Expected demand panel results:"
echo "  • Nearby drivers: ~8–14   (was ~20+)"
echo "  • Nearby riders:  ~15–25  (was ~5–8)"
echo "  • Demand ratio:   1.3–2.0x (surge territory)"
echo "════════════════════════════════════════════════════"
echo ""
echo "Watch live balance:"
echo "  aws logs tail /aws/lambda/expire-riders-lambda --follow --region $REGION"